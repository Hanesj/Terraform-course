def lambdaFn(event, context):
    return {"status": 200, "msg": "Hello from lambda & terraform"}
